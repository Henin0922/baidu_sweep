#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT


public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

    void setRows(int rows);
    void setCols(int cols);
    void setMine(int mine);

    int getRows();
    int getCols();
    int getMine();

    QLineEdit *edit_row;
    QLineEdit *edit_col;
    QLineEdit *edit_mine;

    QLabel *label_row;
    QLabel *label_col;
    QLabel *label_mine;
signals:
    void dia_test();
public slots:
    void up_all();
private:
    Ui::Dialog *ui;

    QPushButton *up;
    int rows;
    int cols;
    int mine;
};

#endif // DIALOG_H
