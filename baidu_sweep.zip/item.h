#ifndef ITEM_H
#define ITEM_H

#include <QPoint>



class Item
{
public:
    Item();
    Item(QPoint pos);
    //物体所在位置
    QPoint m_pos;

    //是否是雷
    bool isMine;
    //是否已标记为雷
    bool isMarked;
    //是否已打开，且非雷
    bool isOpen;

    //数字
    int number;

};

#endif // ITEM_H
